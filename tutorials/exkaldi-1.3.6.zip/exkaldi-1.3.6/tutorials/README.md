# STEP BY STEP

## CREATE ENVIRONMENT

### KALDI

- create environment `kaldi`

- install kaldi

### TEST

- create environment `test`

- install `kenlm` and `exkaldi`

- install `libboost==1.65.1` by `conda`

- install `tensorflow`, `python-flatbuffers`, `tensorboard`