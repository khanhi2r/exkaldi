from __future__ import absolute_import

from exkaldi.utils import utils
from exkaldi.utils import declare
from exkaldi.utils.utils import check_config
from exkaldi.utils.argparse import args
from exkaldi.utils.argparse import load_args