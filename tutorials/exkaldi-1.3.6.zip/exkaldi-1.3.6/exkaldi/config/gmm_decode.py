config = {
            "--beam-delta":[0.5,float],
            "--delta":[0.000976562,float],
            "--determinize-lattice":['true',str],
            "--hash-ratio":[2,float],
            "--minimize":['false',str],
            "--phone-determinize":['true',str],
            "--prune-interval":[25,int],
            "--word-determinize":['true',str],
            "--minimize":['false',str],
}