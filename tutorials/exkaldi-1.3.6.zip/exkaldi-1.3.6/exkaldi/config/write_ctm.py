config={
    "--confidence-digits":[2,int],
    "--decode-mbr":["true",str],
    "--frame-shift":[0.01,float],
    "--inv-acoustic-scale":[1.0,float],
    "--print-silence":["true",str],
}