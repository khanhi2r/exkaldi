config =  {
				"--blackman-coeff":[0.42,float],
				"--channel":[-1,int],
				"--dither":[1.0,float],
				"--energy-floor":[0,float],
				"--max-feature-vectors":[-1,int],
				"--min-duration":[0,int],
				"--output-format":["kaldi",str],
				"--preemphasis-coefficient":[0.97,float],
				"--raw-energy":["true",str],
				"--remove-dc-offset":["true",str],
				"--round-to-power-of-two":["true",str],
				"--snip-edges":["true",str],
				"--subtract-mean":["false",str],
				"--write-utt2dur":["",str]
			} 